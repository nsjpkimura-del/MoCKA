External Verification Pack

Files:
- audit.db
- ed25519_public.key
- final_chain_hash.txt
- verify_full_chain_and_signature.py (if included)

Verify:
1) Put this folder on a clean machine.
2) Run:
   python verify_full_chain_and_signature.py

Expected final_chain_hash:
33a71502fde5540eed1939a017410e137e580c583477129313e679096e453f39
